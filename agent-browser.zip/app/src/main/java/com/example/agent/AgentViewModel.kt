package com.example.agent

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.MultiAiModelProvider
import com.example.browser.BrowserEngine
import com.example.browser.PageUnderstandingBridge
import com.example.data.local.UserPreferenceEntity
import com.example.data.repository.BrowserRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class AgentViewModel(
    application: Application,
    private val repository: BrowserRepository,
    private val engine: BrowserEngine
) : AndroidViewModel(application) {

    private val aiProvider = MultiAiModelProvider()
    private val planner = AgentPlanner(aiProvider)
    private val executor = AgentExecutor(planner, repository)

    val taskState: StateFlow<TaskProgressState> = executor.taskState

    private val _promptInput = MutableStateFlow("")
    val promptInput: StateFlow<String> = _promptInput.asStateFlow()

    private val _isListeningVoice = MutableStateFlow(false)
    val isListeningVoice: StateFlow<Boolean> = _isListeningVoice.asStateFlow()

    private val _chatMessages = MutableStateFlow<List<AgentChatMessage>>(emptyList())
    val chatMessages: StateFlow<List<AgentChatMessage>> = _chatMessages.asStateFlow()

    private var latestReportData: AgentReportData? = null
    private var lastUserPrompt: String = ""

    init {
        // Collect taskState to automatically update conversation history
        viewModelScope.launch {
            taskState.collect { state ->
                if (state.status == TaskStatus.COMPLETED && !state.summaryResult.isNullOrBlank()) {
                    latestReportData = state.reportData
                    val report = state.reportData
                    val lastMsg = _chatMessages.value.lastOrNull()
                    if (lastMsg?.sender != MessageSender.AGENT || lastMsg.text != state.summaryResult) {
                        _chatMessages.value = _chatMessages.value + AgentChatMessage(
                            sender = MessageSender.AGENT,
                            text = state.summaryResult,
                            reportData = report
                        )
                    }
                } else if (state.status == TaskStatus.FAILED && !state.errorMessage.isNullOrBlank()) {
                    val lastMsg = _chatMessages.value.lastOrNull()
                    if (lastMsg?.sender != MessageSender.AGENT || lastMsg.text != state.errorMessage) {
                        _chatMessages.value = _chatMessages.value + AgentChatMessage(
                            sender = MessageSender.AGENT,
                            text = "خطا در انجام عملیات: ${state.errorMessage}"
                        )
                    }
                }
            }
        }
    }

    fun onPromptInputChanged(newText: String) {
        _promptInput.value = newText
    }

    fun submitAgentTask(prompt: String = _promptInput.value) {
        val trimmed = prompt.trim()
        if (trimmed.isBlank()) return

        _promptInput.value = ""
        lastUserPrompt = trimmed

        // Add user message to conversation
        _chatMessages.value = _chatMessages.value + AgentChatMessage(
            sender = MessageSender.USER,
            text = trimmed
        )

        val isWebAction = isWebActionCommand(trimmed)

        if (isWebAction) {
            viewModelScope.launch {
                val userPrefs = repository.userPreferences.firstOrNull() ?: UserPreferenceEntity()
                executor.startTask(
                    userPrompt = trimmed,
                    getPageState = { engine.extractPageState() },
                    executeActionInBrowser = { action -> executeActionInBrowser(action) },
                    preferences = userPrefs,
                    scope = viewModelScope
                )
            }
        } else {
            // Conversational response or follow-up question
            viewModelScope.launch(Dispatchers.Default) {
                kotlinx.coroutines.delay(600) // Realistic conversational pause
                val reply = aiProvider.answerConversationalQuestion(
                    question = trimmed,
                    reportData = latestReportData,
                    userPrompt = lastUserPrompt
                )
                _chatMessages.value = _chatMessages.value + AgentChatMessage(
                    sender = MessageSender.AGENT,
                    text = reply,
                    reportData = latestReportData
                )
            }
        }
    }

    private fun isWebActionCommand(text: String): Boolean {
        val lower = text.lowercase()
        return lower.contains("دیوار") || lower.contains("divar") ||
                lower.contains("ترب") || lower.contains("torob") ||
                lower.contains("دیجی کالا") || lower.contains("digikala") ||
                lower.contains("جستجو") || lower.contains("سرچ") ||
                lower.contains("search") || lower.contains("پیدا کن") ||
                lower.contains("برو به") || lower.contains("سایت") ||
                lower.startsWith("http://") || lower.startsWith("https://") ||
                lower.contains("خرید") || lower.contains("آگهی")
    }

    fun openUrlInBrowser(url: String) {
        if (url.isNotBlank()) {
            engine.loadUrl(url)
        }
    }

    private suspend fun executeActionInBrowser(action: AgentAction): Boolean = withContext(Dispatchers.Main) {
        try {
            when (action) {
                is AgentAction.Navigate -> {
                    engine.loadUrl(action.url)
                    kotlinx.coroutines.delay(3000L)
                    true
                }
                is AgentAction.Click -> {
                    engine.executeJs(PageUnderstandingBridge.buildClickJs(action.targetId))
                    kotlinx.coroutines.delay(1200L)
                    true
                }
                is AgentAction.Type -> {
                    engine.executeJs(PageUnderstandingBridge.buildTypeJs(action.targetId, action.value))
                    kotlinx.coroutines.delay(1000L)
                    true
                }
                is AgentAction.Clear -> {
                    engine.executeJs(PageUnderstandingBridge.buildClearJs(action.targetId))
                    true
                }
                is AgentAction.Scroll -> {
                    engine.executeJs(PageUnderstandingBridge.buildScrollJs(action.direction))
                    kotlinx.coroutines.delay(1000L)
                    true
                }
                is AgentAction.Select -> {
                    engine.executeJs(PageUnderstandingBridge.buildSelectJs(action.targetId, action.value))
                    true
                }
                is AgentAction.Check -> {
                    engine.executeJs(PageUnderstandingBridge.buildClickJs(action.targetId))
                    true
                }
                is AgentAction.Back -> {
                    engine.goBack()
                    kotlinx.coroutines.delay(1500L)
                    true
                }
                is AgentAction.Forward -> {
                    engine.goForward()
                    kotlinx.coroutines.delay(1500L)
                    true
                }
                is AgentAction.Reload -> {
                    engine.reload()
                    kotlinx.coroutines.delay(2000L)
                    true
                }
                is AgentAction.Wait -> {
                    kotlinx.coroutines.delay(action.seconds * 1000L)
                    true
                }
                is AgentAction.OpenTab -> {
                    engine.createNewTab(action.url ?: "https://www.google.com")
                    kotlinx.coroutines.delay(2000L)
                    true
                }
                is AgentAction.CloseTab -> {
                    val current = engine.getActiveTab()
                    if (current != null) {
                        engine.closeTab(current.id)
                    }
                    true
                }
                is AgentAction.SwitchTab -> {
                    engine.switchTab(action.tabId)
                    true
                }
                is AgentAction.Stop -> true
                else -> true
            }
        } catch (t: Throwable) {
            true
        }
    }

    fun pauseAgent() {
        executor.pauseTask()
    }

    fun resumeAgent() {
        executor.resumeTask()
    }

    fun cancelAgent() {
        executor.cancelTask()
    }

    fun toggleVoiceInput() {
        _isListeningVoice.value = !_isListeningVoice.value
    }

    fun clearChat() {
        _chatMessages.value = emptyList()
    }
}
