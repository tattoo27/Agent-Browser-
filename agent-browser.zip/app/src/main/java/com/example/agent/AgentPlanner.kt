package com.example.agent

import com.example.ai.AiModelProvider
import com.example.browser.PageState
import com.example.data.local.UserPreferenceEntity
import com.example.security.HumanInTheLoopManager

class AgentPlanner(
    private val aiProvider: AiModelProvider
) {
    suspend fun getNextAction(
        userPrompt: String,
        pageState: PageState,
        actionHistory: List<AgentAction>,
        preferences: UserPreferenceEntity
    ): Result<AgentAction> {
        // Loop detection: Check if last 3 actions were identical
        if (actionHistory.size >= 4) {
            val last4 = actionHistory.takeLast(4)
            if (last4.all { it.type == last4[0].type && it.describe() == last4[0].describe() }) {
                return Result.success(
                    AgentAction.Stop(
                        resultMessage = "Agent detected an action loop and stopped to prevent endless execution.",
                        reason = "Loop detection rule triggered",
                        isSuccess = false
                    )
                )
            }
        }

        val planResult = aiProvider.planNextAction(
            userPrompt = userPrompt,
            pageState = pageState,
            actionHistory = actionHistory,
            preferences = preferences
        )
        return planResult.map { action ->
            val needsConfirmation = HumanInTheLoopManager.requiresConfirmation(
                action = action,
                pageState = pageState,
                alwaysConfirmSensitive = preferences.confirmDangerousActions
            )
            if (needsConfirmation) {
                when (action) {
                    is AgentAction.Navigate -> action.copy(requiresConfirmation = true)
                    is AgentAction.Click -> action.copy(requiresConfirmation = true)
                    is AgentAction.Type -> action.copy(requiresConfirmation = true)
                    else -> action
                }
            } else {
                action
            }
        }
    }
}
