package com.example.agent

import com.example.browser.PageState
import com.example.browser.PageUnderstandingBridge
import com.example.data.local.AgentStepEntity
import com.example.data.local.AgentTaskEntity
import com.example.data.local.UserPreferenceEntity
import com.example.data.repository.BrowserRepository
import com.example.security.ConfirmationRequest
import com.example.security.HumanInTheLoopManager
import kotlin.coroutines.coroutineContext
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class TaskStatus {
    IDLE,
    PLANNING,
    WAITING_CONFIRMATION,
    EXECUTING,
    VERIFYING,
    COMPLETED,
    PAUSED,
    FAILED,
    CANCELLED
}

data class TaskProgressState(
    val taskId: String? = null,
    val userPrompt: String = "",
    val status: TaskStatus = TaskStatus.IDLE,
    val currentStepIndex: Int = 0,
    val maxSteps: Int = 50,
    val actionHistory: List<AgentAction> = emptyList(),
    val currentAction: AgentAction? = null,
    val pendingConfirmation: ConfirmationRequest? = null,
    val errorMessage: String? = null,
    val summaryResult: String? = null,
    val reportData: AgentReportData? = null
)

class AgentExecutor(
    private val planner: AgentPlanner,
    private val repository: BrowserRepository
) {
    private val _taskState = MutableStateFlow(TaskProgressState())
    val taskState: StateFlow<TaskProgressState> = _taskState.asStateFlow()

    private var executionJob: Job? = null
    private var isPaused = false

    fun startTask(
        userPrompt: String,
        getPageState: suspend () -> PageState,
        executeActionInBrowser: suspend (AgentAction) -> Boolean,
        preferences: UserPreferenceEntity,
        scope: CoroutineScope
    ) {
        cancelTask()

        val taskId = java.util.UUID.randomUUID().toString()
        val maxSteps = preferences.maxStepsPerTask
        _taskState.value = TaskProgressState(
            taskId = taskId,
            userPrompt = userPrompt,
            status = TaskStatus.PLANNING,
            currentStepIndex = 0,
            maxSteps = maxSteps,
            actionHistory = emptyList()
        )

        scope.launch {
            repository.saveTask(
                AgentTaskEntity(
                    id = taskId,
                    userPrompt = userPrompt,
                    status = TaskStatus.PLANNING.name,
                    maxSteps = maxSteps
                )
            )
        }

        executionJob = scope.launch(Dispatchers.Default) {
            runExecutionLoop(
                taskId = taskId,
                userPrompt = userPrompt,
                getPageState = getPageState,
                executeActionInBrowser = executeActionInBrowser,
                preferences = preferences
            )
        }
    }

    private suspend fun runExecutionLoop(
        taskId: String,
        userPrompt: String,
        getPageState: suspend () -> PageState,
        executeActionInBrowser: suspend (AgentAction) -> Boolean,
        preferences: UserPreferenceEntity
    ) {
        val actionHistory = mutableListOf<AgentAction>()
        var stepCount = 0
        val maxSteps = preferences.maxStepsPerTask

        while (coroutineContext.isActive && stepCount < maxSteps) {
            while (isPaused) {
                delay(500)
            }

            _taskState.value = _taskState.value.copy(
                status = TaskStatus.PLANNING,
                currentStepIndex = stepCount
            )

            // 1. Observe Page State
            val currentPageState = try {
                getPageState()
            } catch (e: Exception) {
                failTask(taskId, "Failed to capture webpage state: ${e.message}")
                return
            }

            // 2. Plan Next Action
            val planResult = planner.getNextAction(
                userPrompt = userPrompt,
                pageState = currentPageState,
                actionHistory = actionHistory,
                preferences = preferences
            )

            if (planResult.isFailure) {
                val err = planResult.exceptionOrNull()?.message ?: "Planning failed"
                failTask(taskId, err)
                return
            }

            val action = planResult.getOrThrow()
            _taskState.value = _taskState.value.copy(currentAction = action)

            // Save step entity
            repository.saveStep(
                AgentStepEntity(
                    taskId = taskId,
                    stepIndex = stepCount,
                    actionType = action.type.name,
                    reasoning = action.reason,
                    pageUrl = currentPageState.url,
                    status = "PLANNED"
                )
            )

            // 3. Stop check
            if (action is AgentAction.Stop) {
                completeTask(taskId, action.resultMessage, action.reportData)
                return
            }

            // 4. Human in the Loop Confirmation if required
            if (action.requiresConfirmation) {
                var isConfirmed = false
                var isDenied = false

                val confirmationRequest = HumanInTheLoopManager.buildConfirmationRequest(
                    action = action,
                    pageState = currentPageState,
                    onConfirm = {
                        isConfirmed = true
                    },
                    onCancel = {
                        isDenied = true
                    }
                )

                _taskState.value = _taskState.value.copy(
                    status = TaskStatus.WAITING_CONFIRMATION,
                    pendingConfirmation = confirmationRequest
                )

                while (!isConfirmed && !isDenied && coroutineContext.isActive) {
                    delay(300)
                }

                _taskState.value = _taskState.value.copy(pendingConfirmation = null)

                if (isDenied) {
                    failTask(taskId, "User denied confirmation for action: ${action.describe()}")
                    return
                }
            }

            // 5. Execute Action in Browser
            _taskState.value = _taskState.value.copy(status = TaskStatus.EXECUTING)
            
            var success = false
            var retryCount = 0
            while (!success && retryCount < 3 && coroutineContext.isActive) {
                success = try {
                    withTimeout(15000) {
                        executeActionInBrowser(action)
                    }
                } catch (e: Exception) {
                    false
                }
                if (!success) {
                    retryCount++
                    delay(1000)
                }
            }

            if (!success) {
                failTask(taskId, "Failed to execute action after $retryCount retries: ${action.describe()}")
                return
            }

            actionHistory.add(action)
            _taskState.value = _taskState.value.copy(actionHistory = actionHistory.toList())
            stepCount++

            // Short pause to let page re-render/navigate
            delay(2000)
        }

        if (stepCount >= maxSteps) {
            failTask(taskId, "Task reached maximum allowed step limit ($maxSteps steps).")
        }
    }

    fun pauseTask() {
        isPaused = true
        _taskState.value = _taskState.value.copy(status = TaskStatus.PAUSED)
    }

    fun resumeTask() {
        isPaused = false
        _taskState.value = _taskState.value.copy(status = TaskStatus.EXECUTING)
    }

    fun cancelTask() {
        executionJob?.cancel()
        executionJob = null
        val taskId = _taskState.value.taskId
        _taskState.value = TaskProgressState(status = TaskStatus.CANCELLED)
    }

    private suspend fun completeTask(taskId: String, summary: String, reportData: AgentReportData? = null) {
        _taskState.value = _taskState.value.copy(
            status = TaskStatus.COMPLETED,
            summaryResult = summary,
            reportData = reportData
        )
        repository.saveTask(
            AgentTaskEntity(
                id = taskId,
                userPrompt = _taskState.value.userPrompt,
                status = TaskStatus.COMPLETED.name,
                completedAt = System.currentTimeMillis(),
                resultSummary = summary
            )
        )
    }

    private suspend fun failTask(taskId: String, error: String) {
        _taskState.value = _taskState.value.copy(
            status = TaskStatus.FAILED,
            errorMessage = error
        )
        repository.saveTask(
            AgentTaskEntity(
                id = taskId,
                userPrompt = _taskState.value.userPrompt,
                status = TaskStatus.FAILED.name,
                completedAt = System.currentTimeMillis(),
                resultSummary = "Error: $error"
            )
        )
    }
}
