package com.example.agent

enum class ActionType {
    NAVIGATE,
    CLICK,
    TYPE,
    CLEAR,
    SCROLL,
    SELECT,
    CHECK,
    UNCHECK,
    BACK,
    FORWARD,
    RELOAD,
    WAIT,
    OPEN_TAB,
    CLOSE_TAB,
    SWITCH_TAB,
    FIND,
    STOP
}

sealed class AgentAction(
    val type: ActionType,
    open val reason: String,
    open val requiresConfirmation: Boolean = false
) {
    data class Navigate(
        val url: String,
        override val reason: String,
        override val requiresConfirmation: Boolean = false
    ) : AgentAction(ActionType.NAVIGATE, reason, requiresConfirmation)

    data class Click(
        val targetId: String,
        override val reason: String,
        override val requiresConfirmation: Boolean = false
    ) : AgentAction(ActionType.CLICK, reason, requiresConfirmation)

    data class Type(
        val targetId: String,
        val value: String,
        override val reason: String,
        override val requiresConfirmation: Boolean = false
    ) : AgentAction(ActionType.TYPE, reason, requiresConfirmation)

    data class Clear(
        val targetId: String,
        override val reason: String
    ) : AgentAction(ActionType.CLEAR, reason)

    data class Scroll(
        val direction: String, // "up" or "down"
        override val reason: String
    ) : AgentAction(ActionType.SCROLL, reason)

    data class Select(
        val targetId: String,
        val value: String,
        override val reason: String
    ) : AgentAction(ActionType.SELECT, reason)

    data class Check(
        val targetId: String,
        val check: Boolean = true,
        override val reason: String
    ) : AgentAction(ActionType.CHECK, reason)

    data class Back(
        override val reason: String
    ) : AgentAction(ActionType.BACK, reason)

    data class Forward(
        override val reason: String
    ) : AgentAction(ActionType.FORWARD, reason)

    data class Reload(
        override val reason: String
    ) : AgentAction(ActionType.RELOAD, reason)

    data class Wait(
        val seconds: Int = 3,
        override val reason: String
    ) : AgentAction(ActionType.WAIT, reason)

    data class OpenTab(
        val url: String? = null,
        override val reason: String
    ) : AgentAction(ActionType.OPEN_TAB, reason)

    data class CloseTab(
        val tabId: String? = null,
        override val reason: String
    ) : AgentAction(ActionType.CLOSE_TAB, reason)

    data class SwitchTab(
        val tabId: String,
        override val reason: String
    ) : AgentAction(ActionType.SWITCH_TAB, reason)

    data class Find(
        val text: String,
        override val reason: String
    ) : AgentAction(ActionType.FIND, reason)

    data class Stop(
        val resultMessage: String,
        override val reason: String,
        val isSuccess: Boolean = true,
        val reportData: AgentReportData? = null
    ) : AgentAction(ActionType.STOP, reason)

    fun describe(): String {
        return when (this) {
            is Navigate -> "Navigate to $url"
            is Click -> "Click element '$targetId'"
            is Type -> "Type \"$value\" into element '$targetId'"
            is Clear -> "Clear element '$targetId'"
            is Scroll -> "Scroll $direction"
            is Select -> "Select option \"$value\" in element '$targetId'"
            is Check -> "Toggle checkbox '$targetId'"
            is Back -> "Go back"
            is Forward -> "Go forward"
            is Reload -> "Reload page"
            is Wait -> "Wait $seconds seconds"
            is OpenTab -> "Open new tab ${url ?: ""}"
            is CloseTab -> "Close tab ${tabId ?: "current"}"
            is SwitchTab -> "Switch to tab $tabId"
            is Find -> "Find text \"$text\" on page"
            is Stop -> "Task completed: $resultMessage"
        }
    }
}
