package com.example.agent

data class ThinkingStep(
    val title: String,
    val description: String,
    val phase: String = "استدلال منطقی"
)

data class AgentListingItem(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val price: String,
    val category: String, // "رده‌بالا الترا", "میان‌رده پیشرفته", "اقتصادی ارزنده"
    val specs: String,
    val cpu: String = "",
    val gpu: String = "",
    val ram: String = "",
    val storage: String = "",
    val psu: String = "",
    val fpsBenchmark: String = "",
    val valueScore: String, // e.g. "۹.۸ از ۱۰ - ارزش خرید فوق‌العاده"
    val pros: List<String> = emptyList(),
    val cons: List<String> = emptyList(),
    val linkUrl: String,
    val platform: String = "دیوار"
)

data class AgentReportData(
    val title: String,
    val summary: String,
    val thinkingSteps: List<ThinkingStep> = emptyList(),
    val items: List<AgentListingItem> = emptyList(),
    val tips: List<String> = emptyList(),
    val platform: String = "دیوار"
)

enum class MessageSender {
    USER,
    AGENT
}

data class AgentChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val thinkingText: String? = null,
    val reportData: AgentReportData? = null,
    val timestamp: Long = System.currentTimeMillis()
)
