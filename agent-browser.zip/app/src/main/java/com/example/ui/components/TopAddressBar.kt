package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.browser.BrowserTabModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TopAddressBar(
    activeTab: BrowserTabModel?,
    urlText: String,
    onUrlChange: (String) -> Unit,
    onNavigate: () -> Unit,
    isBookmarked: Boolean,
    onToggleBookmark: () -> Unit,
    onToggleDesktopMode: () -> Unit,
    onVoiceInputClick: () -> Unit,
    onReloadClick: () -> Unit,
    onStopClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val focusManager = LocalFocusManager.current
    val isHttps = activeTab?.url?.startsWith("https://") == true
    val isLoading = activeTab?.isLoading == true
    val progress = activeTab?.progress ?: 0

    Surface(
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 2.dp,
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Address Bar Container
                OutlinedTextField(
                    value = urlText,
                    onValueChange = onUrlChange,
                    modifier = Modifier
                        .weight(1f)
                        .height(52.dp)
                        .testTag("address_bar_input"),
                    shape = RoundedCornerShape(26.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f),
                        unfocusedBorderColor = Color.Transparent,
                        focusedBorderColor = MaterialTheme.colorScheme.primary
                    ),
                    singleLine = true,
                    leadingIcon = {
                        Icon(
                            imageVector = if (isHttps) Icons.Filled.Lock else Icons.Outlined.LockOpen,
                            contentDescription = if (isHttps) "Secure HTTPS" else "Unsecure Connection",
                            tint = if (isHttps) Color(0xFF10B981) else MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(18.dp)
                        )
                    },
                    trailingIcon = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (urlText.isNotBlank()) {
                                IconButton(
                                    onClick = { onUrlChange("") },
                                    modifier = Modifier
                                        .size(28.dp)
                                        .testTag("clear_url_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Clear URL",
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                            IconButton(
                                onClick = onVoiceInputClick,
                                modifier = Modifier
                                    .size(32.dp)
                                    .testTag("voice_input_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Mic,
                                    contentDescription = "Voice Input",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(
                        onGo = {
                            focusManager.clearFocus()
                            onNavigate()
                        }
                    ),
                    textStyle = MaterialTheme.typography.bodyMedium.copy(fontSize = 14.sp)
                )

                // Bookmark Icon Button
                IconButton(
                    onClick = onToggleBookmark,
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("bookmark_button")
                ) {
                    Icon(
                        imageVector = if (isBookmarked) Icons.Filled.Star else Icons.Outlined.StarBorder,
                        contentDescription = "Bookmark",
                        tint = if (isBookmarked) Color(0xFFF59E0B) else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Desktop / Mobile Toggle Button
                IconButton(
                    onClick = onToggleDesktopMode,
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("desktop_toggle_button")
                ) {
                    Icon(
                        imageVector = if (activeTab?.isDesktopMode == true) Icons.Default.DesktopWindows else Icons.Default.Smartphone,
                        contentDescription = "Toggle Desktop Mode",
                        tint = if (activeTab?.isDesktopMode == true) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Reload or Stop Button
                IconButton(
                    onClick = if (isLoading) onStopClick else onReloadClick,
                    modifier = Modifier
                        .size(40.dp)
                        .testTag("reload_stop_button")
                ) {
                    Icon(
                        imageVector = if (isLoading) Icons.Default.Close else Icons.Default.Refresh,
                        contentDescription = if (isLoading) "Stop Loading" else "Reload Page"
                    )
                }
            }

            // Linear Loading Progress Bar
            if (isLoading) {
                LinearProgressIndicator(
                    progress = { progress / 100f },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = Color.Transparent
                )
            }
        }
    }
}
