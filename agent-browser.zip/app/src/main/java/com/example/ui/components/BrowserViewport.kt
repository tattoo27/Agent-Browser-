package com.example.ui.components

import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.widget.FrameLayout
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import com.example.browser.BrowserEngine
import com.example.browser.BrowserTabModel

@Composable
fun BrowserViewport(
    activeTab: BrowserTabModel?,
    engine: BrowserEngine? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        if (activeTab != null) {
            AndroidView(
                factory = { ctx ->
                    val frameLayout = FrameLayout(ctx)
                    try {
                        val webView = activeTab.webView ?: engine?.ensureWebViewForTab(activeTab.id, ctx)
                        if (webView != null) {
                            (webView.parent as? ViewGroup)?.removeView(webView)
                            webView.layoutParams = FrameLayout.LayoutParams(
                                FrameLayout.LayoutParams.MATCH_PARENT,
                                FrameLayout.LayoutParams.MATCH_PARENT
                            )
                            frameLayout.addView(webView)
                        }
                    } catch (t: Throwable) {
                        // Catch any WebView initialization or layout errors gracefully
                    }
                    frameLayout
                },
                update = { frame ->
                    try {
                        val webView = activeTab.webView ?: engine?.ensureWebViewForTab(activeTab.id, frame.context)
                        if (webView != null && webView.parent != frame) {
                            (webView.parent as? ViewGroup)?.removeView(webView)
                            frame.removeAllViews()
                            webView.layoutParams = FrameLayout.LayoutParams(
                                FrameLayout.LayoutParams.MATCH_PARENT,
                                FrameLayout.LayoutParams.MATCH_PARENT
                            )
                            frame.addView(webView)
                        }
                    } catch (t: Throwable) {
                        // Ignore view updates if WebView fails
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "مرورگر آماده استفاده است",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
        }
    }
}
