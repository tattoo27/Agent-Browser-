package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.example.data.local.UserPreferenceEntity

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsDialog(
    preferences: UserPreferenceEntity,
    onUpdatePreferences: (UserPreferenceEntity) -> Unit,
    onClearHistory: () -> Unit,
    onDismiss: () -> Unit
) {
    var confirmSensitive by remember(preferences) { mutableStateOf(preferences.confirmDangerousActions) }
    var searchEngine by remember(preferences) { mutableStateOf(preferences.preferredSearchEngine) }
    var maxSteps by remember(preferences) { mutableStateOf(preferences.maxStepsPerTask) }
    
    var provider by remember(preferences) { mutableStateOf(preferences.selectedAiProvider) }
    var selectedModel by remember(preferences) { mutableStateOf(preferences.selectedAiModel) }
    
    var geminiKey by remember(preferences) { mutableStateOf(preferences.geminiApiKey) }
    var openAiKey by remember(preferences) { mutableStateOf(preferences.openAiApiKey) }
    var claudeKey by remember(preferences) { mutableStateOf(preferences.claudeApiKey) }
    var customBaseUrl by remember(preferences) { mutableStateOf(preferences.customApiBaseUrl) }
    var customKey by remember(preferences) { mutableStateOf(preferences.customApiKey) }
    
    var isKeyVisible by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp,
            shadowElevation = 12.dp,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 620.dp)
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Psychology,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            text = "Browser & AI Settings",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // AI Provider Selection
                Text(
                    text = "AI Model Provider",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))

                val providers = listOf(
                    "FREE" to "⚡ Free Mode (No Key)",
                    "GEMINI" to "Google Gemini",
                    "OPENAI" to "OpenAI ChatGPT",
                    "CLAUDE" to "Anthropic Claude",
                    "CUSTOM_OPENAI" to "Custom Gateway"
                )

                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    providers.chunked(2).forEach { row ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            row.forEach { (key, label) ->
                                FilterChip(
                                    selected = provider == key,
                                    onClick = {
                                        provider = key
                                        val defaultModel = when (key) {
                                            "OPENAI" -> "gpt-4o-mini"
                                            "CLAUDE" -> "claude-3-5-sonnet-20241022"
                                            "CUSTOM_OPENAI" -> "gpt-4o-mini"
                                            "GEMINI" -> "gemini-2.5-flash"
                                            else -> "free-heuristic"
                                        }
                                        selectedModel = defaultModel
                                        onUpdatePreferences(
                                            preferences.copy(
                                                selectedAiProvider = key,
                                                selectedAiModel = defaultModel
                                            )
                                        )
                                    },
                                    label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Dynamic API Key / Base URL Fields
                when (provider) {
                    "FREE" -> {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "⚡ حالت هوشمند رایگان (بدون نیاز به API Key)",
                                    style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "در این حالت بدون نیاز به ساخت یا وارد کردن کلید API، مرورگر به‌صورت خودکار و رایگان دستورات پیمایش، انجام جستجو و یافتن اطلاعات را انجام می‌دهد.",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                    "GEMINI" -> {
                        OutlinedTextField(
                            value = geminiKey,
                            onValueChange = {
                                geminiKey = it
                                onUpdatePreferences(preferences.copy(geminiApiKey = it.trim()))
                            },
                            label = { Text("Gemini API Key") },
                            placeholder = { Text("AIzaSy...") },
                            leadingIcon = { Icon(Icons.Default.Key, contentDescription = null) },
                            trailingIcon = {
                                TextButton(onClick = { isKeyVisible = !isKeyVisible }) {
                                    Text(if (isKeyVisible) "Hide" else "Show")
                                }
                            },
                            visualTransformation = if (isKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    "OPENAI" -> {
                        OutlinedTextField(
                            value = openAiKey,
                            onValueChange = {
                                openAiKey = it
                                onUpdatePreferences(preferences.copy(openAiApiKey = it.trim()))
                            },
                            label = { Text("OpenAI API Key") },
                            placeholder = { Text("sk-proj-...") },
                            leadingIcon = { Icon(Icons.Default.Key, contentDescription = null) },
                            trailingIcon = {
                                TextButton(onClick = { isKeyVisible = !isKeyVisible }) {
                                    Text(if (isKeyVisible) "Hide" else "Show")
                                }
                            },
                            visualTransformation = if (isKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    "CLAUDE" -> {
                        OutlinedTextField(
                            value = claudeKey,
                            onValueChange = {
                                claudeKey = it
                                onUpdatePreferences(preferences.copy(claudeApiKey = it.trim()))
                            },
                            label = { Text("Anthropic Claude API Key") },
                            placeholder = { Text("sk-ant-...") },
                            leadingIcon = { Icon(Icons.Default.Key, contentDescription = null) },
                            trailingIcon = {
                                TextButton(onClick = { isKeyVisible = !isKeyVisible }) {
                                    Text(if (isKeyVisible) "Hide" else "Show")
                                }
                            },
                            visualTransformation = if (isKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    "CUSTOM_OPENAI" -> {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = customBaseUrl,
                                onValueChange = {
                                    customBaseUrl = it
                                    onUpdatePreferences(preferences.copy(customApiBaseUrl = it.trim()))
                                },
                                label = { Text("Base Gateway URL") },
                                placeholder = { Text("https://my-proxy.com or http://192.168.1.10:11434") },
                                leadingIcon = { Icon(Icons.Default.Dns, contentDescription = null) },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                            OutlinedTextField(
                                value = customKey,
                                onValueChange = {
                                    customKey = it
                                    onUpdatePreferences(preferences.copy(customApiKey = it.trim()))
                                },
                                label = { Text("API Key / Bearer Token (Optional)") },
                                placeholder = { Text("Bearer token if required") },
                                leadingIcon = { Icon(Icons.Default.Key, contentDescription = null) },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // AI Agent Security Section
                Text(
                    text = "AI Agent & Security",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Human-in-the-Loop Confirmation", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                        Text("Require user approval before purchases, payments, passwords, or deletions.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(
                        checked = confirmSensitive,
                        onCheckedChange = {
                            confirmSensitive = it
                            onUpdatePreferences(preferences.copy(confirmDangerousActions = it))
                        },
                        modifier = Modifier.testTag("confirm_sensitive_switch")
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text("Max Steps Per Task: $maxSteps", style = MaterialTheme.typography.bodyMedium)
                Slider(
                    value = maxSteps.toFloat(),
                    onValueChange = {
                        maxSteps = it.toInt()
                        onUpdatePreferences(preferences.copy(maxStepsPerTask = maxSteps))
                    },
                    valueRange = 10f..100f,
                    steps = 9
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Search Engine Selection
                Text(
                    text = "Search Engine",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))

                val engines = listOf("Google", "DuckDuckGo", "Bing", "Ecosia")
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    engines.forEach { engine ->
                        FilterChip(
                            selected = searchEngine == engine,
                            onClick = {
                                searchEngine = engine
                                onUpdatePreferences(preferences.copy(preferredSearchEngine = engine))
                            },
                            label = { Text(engine) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Privacy
                Text(
                    text = "Privacy & Data",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.primary
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = {
                        onClearHistory()
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Clear Browsing History & Cookies")
                }
            }
        }
    }
}
