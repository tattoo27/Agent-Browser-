package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val AgentIndigoPrimary = Color(0xFF6366F1)
val AgentIndigoDark = Color(0xFF4F46E5)
val AgentCyanAccent = Color(0xFF06B6D4)
val AgentBackgroundDark = Color(0xFF0F172A)
val AgentSurfaceDark = Color(0xFF1E293B)
val AgentCardDark = Color(0xFF334155)

val AgentPrimaryLight = Color(0xFF4F46E5)
val AgentSecondaryLight = Color(0xFF0891B2)
val AgentBackgroundLight = Color(0xFFF8FAFC)
val AgentSurfaceLight = Color(0xFFFFFFFF)
