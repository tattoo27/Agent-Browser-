package com.example.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.agent.AgentViewModel
import com.example.browser.BrowserViewModel
import com.example.ui.components.*

@Composable
fun BrowserMainScreen(
    browserViewModel: BrowserViewModel,
    agentViewModel: AgentViewModel,
    modifier: Modifier = Modifier
) {
    val activeTabId by browserViewModel.activeTabId.collectAsStateWithLifecycle()
    val tabs by browserViewModel.tabs.collectAsStateWithLifecycle()
    val activeTab = tabs.find { it.id == activeTabId } ?: tabs.firstOrNull()

    val urlInputText by browserViewModel.urlInputText.collectAsStateWithLifecycle()
    val isBookmarked by browserViewModel.isBookmarked.collectAsStateWithLifecycle()

    val showTabSwitcher by browserViewModel.showTabSwitcher.collectAsStateWithLifecycle()
    val showBookmarksHistory by browserViewModel.showBookmarksHistory.collectAsStateWithLifecycle()
    val showDownloads by browserViewModel.showDownloads.collectAsStateWithLifecycle()
    val showSettings by browserViewModel.showSettings.collectAsStateWithLifecycle()
    val showAgentSheet by browserViewModel.showAgentSheet.collectAsStateWithLifecycle()

    val userPreferences by browserViewModel.userPreferences.collectAsStateWithLifecycle()
    val bookmarks by browserViewModel.bookmarks.collectAsStateWithLifecycle()
    val history by browserViewModel.history.collectAsStateWithLifecycle()
    val downloads by browserViewModel.downloads.collectAsStateWithLifecycle()

    val agentTaskState by agentViewModel.taskState.collectAsStateWithLifecycle()
    val agentPromptInput by agentViewModel.promptInput.collectAsStateWithLifecycle()
    val agentChatMessages by agentViewModel.chatMessages.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAddressBar(
                activeTab = activeTab,
                urlText = urlInputText,
                onUrlChange = browserViewModel::onUrlInputChanged,
                onNavigate = { browserViewModel.navigateToUrl() },
                isBookmarked = isBookmarked,
                onToggleBookmark = browserViewModel::toggleBookmark,
                onToggleDesktopMode = { browserViewModel.engine.toggleDesktopMode() },
                onVoiceInputClick = { agentViewModel.toggleVoiceInput() },
                onReloadClick = { browserViewModel.engine.reload() },
                onStopClick = { browserViewModel.engine.stopLoading() }
            )
        },
        bottomBar = {
            BottomControlBar(
                activeTab = activeTab,
                tabCount = tabs.size,
                onBackClick = { browserViewModel.engine.goBack() },
                onForwardClick = { browserViewModel.engine.goForward() },
                onHomeClick = { browserViewModel.navigateToUrl("https://www.google.com") },
                onTabsClick = browserViewModel::toggleTabSwitcher,
                onBookmarksHistoryClick = browserViewModel::toggleBookmarksHistory,
                onAgentFabClick = { browserViewModel.toggleAgentSheet(true) },
                onSettingsClick = browserViewModel::toggleSettings
            )
        },
        modifier = modifier.fillMaxSize()
    ) { innerPadding ->
        // Browser Viewport
        BrowserViewport(
            activeTab = activeTab,
            engine = browserViewModel.engine,
            modifier = Modifier.padding(innerPadding)
        )

        // Tab Switcher Modal
        if (showTabSwitcher) {
            TabSwitcherSheet(
                tabs = tabs,
                activeTabId = activeTabId,
                onTabSelect = { tabId -> browserViewModel.engine.switchTab(tabId) },
                onTabClose = { tabId -> browserViewModel.engine.closeTab(tabId) },
                onNewTab = { isIncognito -> browserViewModel.engine.createNewTab(isIncognito = isIncognito) },
                onDismiss = browserViewModel::toggleTabSwitcher
            )
        }

        // Bookmarks & History Dialog
        if (showBookmarksHistory) {
            BookmarksHistoryDialog(
                bookmarks = bookmarks,
                history = history,
                onSelectUrl = { url -> browserViewModel.navigateToUrl(url) },
                onDeleteBookmark = { id ->
                    // Handled in VM
                },
                onDeleteHistory = { id ->
                    // Handled in VM
                },
                onClearHistory = browserViewModel::clearHistory,
                onDismiss = browserViewModel::toggleBookmarksHistory
            )
        }

        // Downloads Dialog
        if (showDownloads) {
            DownloadsDialog(
                downloads = downloads,
                onDeleteDownload = { id -> },
                onDismiss = browserViewModel::toggleDownloads
            )
        }

        // Settings Dialog
        if (showSettings) {
            SettingsDialog(
                preferences = userPreferences,
                onUpdatePreferences = browserViewModel::updatePreferences,
                onClearHistory = browserViewModel::clearHistory,
                onDismiss = browserViewModel::toggleSettings
            )
        }

        // AI Agent Panel Bottom Sheet
        if (showAgentSheet) {
            AgentBottomSheet(
                taskProgressState = agentTaskState,
                chatMessages = agentChatMessages,
                promptText = agentPromptInput,
                onPromptChange = agentViewModel::onPromptInputChanged,
                onSubmitTask = { agentViewModel.submitAgentTask() },
                onOpenUrl = { url ->
                    agentViewModel.openUrlInBrowser(url)
                    browserViewModel.toggleAgentSheet(false)
                },
                onClearChat = agentViewModel::clearChat,
                onPauseAgent = agentViewModel::pauseAgent,
                onResumeAgent = agentViewModel::resumeAgent,
                onCancelAgent = agentViewModel::cancelAgent,
                onDismiss = { browserViewModel.toggleAgentSheet(false) }
            )
        }
    }
}
