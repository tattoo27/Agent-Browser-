package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.AgentAction
import com.example.agent.AgentChatMessage
import com.example.agent.AgentListingItem
import com.example.agent.AgentReportData
import com.example.agent.MessageSender
import com.example.agent.TaskProgressState
import com.example.agent.TaskStatus
import com.example.agent.ThinkingStep
import com.example.security.ConfirmationRequest
import com.example.ui.theme.AgentCyanAccent
import com.example.ui.theme.AgentIndigoPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AgentBottomSheet(
    taskProgressState: TaskProgressState,
    chatMessages: List<AgentChatMessage>,
    promptText: String,
    onPromptChange: (String) -> Unit,
    onSubmitTask: () -> Unit,
    onOpenUrl: (String) -> Unit,
    onClearChat: () -> Unit,
    onPauseAgent: () -> Unit,
    onResumeAgent: () -> Unit,
    onCancelAgent: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableStateOf(if (taskProgressState.reportData != null) 1 else 0) }

    // Auto-switch to results tab once report is ready
    LaunchedEffect(taskProgressState.reportData) {
        if (taskProgressState.reportData != null) {
            selectedTab = 1
        }
    }

    val suggestionChips = listOf(
        "🖥️ سیستم گیمینگ تا ۲۰۰ میلیون در دیوار",
        "🧠 استدلال مقایسه سیستم‌های ۱ و ۲",
        "⚡ تحلیل پاور و مصرف برق قطعات",
        "🛡️ پروتکل تست سلامت کارت گرافیک",
        "📱 بررسی قیمت آیفون ۱۵ پرو مکس در ترب",
        "💻 لپ‌تاپ گیمینگ تا ۶۰ میلیون در دیجی‌کالا"
    )

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
        containerColor = MaterialTheme.colorScheme.surface,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.94f)
                .padding(horizontal = 16.dp, vertical = 6.dp)
                .navigationBarsPadding()
        ) {
            // Elegant Header with Deep Thinking Badge
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = 1.dp,
                        brush = Brush.horizontalGradient(
                            listOf(
                                AgentIndigoPrimary.copy(alpha = 0.8f),
                                AgentCyanAccent.copy(alpha = 0.8f)
                            )
                        ),
                        shape = RoundedCornerShape(20.dp)
                    )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.linearGradient(
                                        listOf(AgentIndigoPrimary, AgentCyanAccent)
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Psychology,
                                contentDescription = "Deep Reasoning",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = "ایجنت کاوشگر و استدلال عمیق",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                )
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = AgentCyanAccent.copy(alpha = 0.2f)
                                ) {
                                    Text(
                                        text = "Deep Reasoning",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = AgentCyanAccent,
                                        fontSize = 9.sp,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = if (taskProgressState.status == TaskStatus.EXECUTING || taskProgressState.status == TaskStatus.PLANNING)
                                    "در حال پیمایش چندمرحله‌ای، کاوش وب و استدلال قطعات..."
                                else
                                    "آماده دریافت دستورات جستجو، استدلال و ادامه چت",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (taskProgressState.status == TaskStatus.EXECUTING) AgentCyanAccent else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // Task Action Controls
                    Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (taskProgressState.status == TaskStatus.EXECUTING || taskProgressState.status == TaskStatus.PLANNING) {
                            IconButton(onClick = onPauseAgent) {
                                Icon(imageVector = Icons.Default.Pause, contentDescription = "Pause")
                            }
                            IconButton(onClick = onCancelAgent) {
                                Icon(imageVector = Icons.Default.Stop, contentDescription = "Stop", tint = MaterialTheme.colorScheme.error)
                            }
                        } else if (taskProgressState.status == TaskStatus.PAUSED) {
                            IconButton(onClick = onResumeAgent) {
                                Icon(imageVector = Icons.Default.PlayArrow, contentDescription = "Resume", tint = AgentIndigoPrimary)
                            }
                        }

                        if (chatMessages.isNotEmpty()) {
                            IconButton(onClick = onClearChat) {
                                Icon(imageVector = Icons.Default.DeleteSweep, contentDescription = "Clear Chat", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Navigation Tabs (Chat vs Listings & Results)
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color.Transparent,
                divider = {},
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = AgentIndigoPrimary
                    )
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(imageVector = Icons.Default.Forum, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("گفتگو و تحلیل با ایجنت", fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(imageVector = Icons.Default.ViewList, contentDescription = null, modifier = Modifier.size(16.dp))
                            Text("نتایج جامع و لیست آگهی‌ها", fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal)
                            val count = taskProgressState.reportData?.items?.size ?: 0
                            if (count > 0) {
                                Surface(
                                    color = AgentIndigoPrimary,
                                    shape = CircleShape,
                                    modifier = Modifier.size(18.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text("$count", style = MaterialTheme.typography.labelSmall, color = Color.White, fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Live Execution Status Banner
            if (taskProgressState.status != TaskStatus.IDLE && taskProgressState.status != TaskStatus.COMPLETED) {
                StatusBanner(taskProgressState)
                if (taskProgressState.status == TaskStatus.PLANNING || taskProgressState.status == TaskStatus.EXECUTING) {
                    Spacer(modifier = Modifier.height(4.dp))
                    LinearProgressIndicator(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(3.dp)
                            .clip(RoundedCornerShape(2.dp)),
                        color = AgentIndigoPrimary,
                        trackColor = AgentIndigoPrimary.copy(alpha = 0.2f)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
            }

            // Pending Confirmation Card
            taskProgressState.pendingConfirmation?.let { confirmation ->
                ConfirmationCard(
                    request = confirmation,
                    modifier = Modifier.padding(vertical = 4.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            // MAIN CONTENT AREA
            Box(modifier = Modifier.weight(1f)) {
                if (selectedTab == 0) {
                    ChatConversationView(
                        chatMessages = chatMessages,
                        taskProgressState = taskProgressState,
                        onOpenUrl = onOpenUrl,
                        onAskAboutItem = { itemTitle ->
                            onPromptChange("درباره قطعات «$itemTitle» و ارزش خرید آن استدلال کن")
                        }
                    )
                } else {
                    ListingsAndReportView(
                        reportData = taskProgressState.reportData,
                        summaryResult = taskProgressState.summaryResult,
                        onOpenUrl = onOpenUrl,
                        onAskAboutItem = { itemTitle ->
                            selectedTab = 0
                            onPromptChange("درباره «$itemTitle» راهنمایی کن که آیا ارزش خرید داره و با چه تستی بررسیش کنم؟")
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Quick Suggestion Chips
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(suggestionChips) { chipText ->
                    SuggestionChip(
                        onClick = {
                            onPromptChange(chipText)
                        },
                        label = {
                            Text(
                                text = chipText,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Medium
                            )
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = SuggestionChipDefaults.suggestionChipColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.35f)
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Continuous Message Input Bar
            OutlinedTextField(
                value = promptText,
                onValueChange = onPromptChange,
                placeholder = {
                    Text(
                        "دستور جستجوی جدید یا سوال با تفکر عمیق بنویسید...",
                        style = MaterialTheme.typography.bodySmall
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("agent_prompt_input"),
                shape = RoundedCornerShape(20.dp),
                trailingIcon = {
                    IconButton(
                        onClick = onSubmitTask,
                        enabled = promptText.isNotBlank(),
                        modifier = Modifier.testTag("agent_submit_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Send,
                            contentDescription = "Send",
                            tint = if (promptText.isNotBlank()) AgentIndigoPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { onSubmitTask() }),
                maxLines = 3
            )
        }
    }
}

@Composable
fun ListingsAndReportView(
    reportData: AgentReportData?,
    summaryResult: String?,
    onOpenUrl: (String) -> Unit,
    onAskAboutItem: (String) -> Unit
) {
    val context = LocalContext.current
    var selectedCategoryFilter by remember { mutableStateOf("همه") }
    var isThinkingExpanded by remember { mutableStateOf(true) }

    val categories = listOf("همه", "رده‌بالا", "میان‌رده", "اقتصادی")

    if (reportData == null && summaryResult.isNullOrBlank()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "هنوز نتیجه‌ای ثبت نشده است",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "یک دستور مانند «سیستم گیمینگ تا ۲۰۰ میلیون در دیوار» را ارسال فرمایید",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        }
        return
    }

    val items = reportData?.items ?: emptyList()
    val filteredItems = if (selectedCategoryFilter == "همه") {
        items
    } else {
        items.filter { it.category.contains(selectedCategoryFilter) || it.title.contains(selectedCategoryFilter) }
    }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // Deep Thinking Process Accordion Card (تفکر عمیق و استدلال مهندسی)
        if (!reportData?.thinkingSteps.isNullOrEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(
                            1.dp,
                            Brush.horizontalGradient(
                                listOf(AgentIndigoPrimary.copy(alpha = 0.5f), AgentCyanAccent.copy(alpha = 0.5f))
                            ),
                            RoundedCornerShape(16.dp)
                        )
                        .animateContentSize()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { isThinkingExpanded = !isThinkingExpanded },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(
                                    imageVector = Icons.Default.Psychology,
                                    contentDescription = null,
                                    tint = AgentCyanAccent,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = "فرآیند تفکر عمیق و استدلال هوش مصنوعی",
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Icon(
                                imageVector = if (isThinkingExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = "Toggle Thinking",
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        if (isThinkingExpanded) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                            Spacer(modifier = Modifier.height(10.dp))

                            reportData!!.thinkingSteps.forEachIndexed { index, step ->
                                Row(
                                    verticalAlignment = Alignment.Top,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    modifier = Modifier.padding(vertical = 4.dp)
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = AgentIndigoPrimary.copy(alpha = 0.2f),
                                        modifier = Modifier.size(22.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "${index + 1}",
                                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                                color = AgentIndigoPrimary,
                                                fontSize = 11.sp
                                            )
                                        }
                                    }
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = step.title,
                                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = step.description,
                                            style = MaterialTheme.typography.labelSmall.copy(lineHeight = 17.sp),
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Summary Overview Card
        item {
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, AgentIndigoPrimary.copy(alpha = 0.3f), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = reportData?.title ?: "گزارش و رده‌بندی سیستم‌ها",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Agent Report", summaryResult ?: reportData?.summary ?: "")
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "گزارش کامل در حافظه کپی شد", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", modifier = Modifier.size(16.dp))
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = reportData?.summary ?: summaryResult ?: "",
                        style = MaterialTheme.typography.bodySmall.copy(lineHeight = 20.sp),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        // Category Filter Chips
        if (items.isNotEmpty()) {
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                    categories.forEach { cat ->
                        FilterChip(
                            selected = selectedCategoryFilter == cat,
                            onClick = { selectedCategoryFilter = cat },
                            label = { Text(cat, style = MaterialTheme.typography.labelSmall) },
                            shape = RoundedCornerShape(10.dp)
                        )
                    }
                }
            }
        }

        // Detailed Listing Cards
        items(filteredItems) { item ->
            DetailedListingCard(
                item = item,
                onOpenUrl = { onOpenUrl(item.linkUrl) },
                onAskAboutItem = { onAskAboutItem(item.title) }
            )
        }

        // Pre-Purchase Testing Safety Checklist
        reportData?.tips?.let { tips ->
            if (tips.isNotEmpty()) {
                item {
                    Spacer(modifier = Modifier.height(4.dp))
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, Color(0xFF10B981).copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(imageVector = Icons.Default.VerifiedUser, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(20.dp))
                                Text("پروتکل طلایی تست سلامت قبل از خرید از دیوار:", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            tips.forEach { tip ->
                                Row(
                                    verticalAlignment = Alignment.Top,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.padding(vertical = 3.dp)
                                ) {
                                    Text("✓", color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                                    Text(text = tip, style = MaterialTheme.typography.bodySmall.copy(lineHeight = 19.sp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DetailedListingCard(
    item: AgentListingItem,
    onOpenUrl: () -> Unit,
    onAskAboutItem: () -> Unit
) {
    var isExpanded by remember { mutableStateOf(false) }

    Surface(
        shape = RoundedCornerShape(18.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f), RoundedCornerShape(18.dp))
            .animateContentSize()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Category & Platform Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = AgentIndigoPrimary.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = item.category,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = AgentIndigoPrimary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFEF4444).copy(alpha = 0.15f)
                ) {
                    Text(
                        text = item.platform,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = Color(0xFFEF4444),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Title
            Text(
                text = item.title,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Price Tag
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(imageVector = Icons.Default.Payments, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(18.dp))
                Text(
                    text = item.price,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = Color(0xFF10B981)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Value Score
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(imageVector = Icons.Default.Star, contentDescription = null, tint = Color(0xFFF59E0B), modifier = Modifier.size(15.dp))
                Text(
                    text = item.valueScore,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = Color(0xFFF59E0B)
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Hardware Specs Grid
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    if (item.cpu.isNotBlank()) {
                        SpecRow("پردازنده (CPU):", item.cpu)
                    }
                    if (item.gpu.isNotBlank()) {
                        SpecRow("کارت گرافیک (GPU):", item.gpu)
                    }
                    if (item.ram.isNotBlank()) {
                        SpecRow("حافظه رم (RAM):", item.ram)
                    }
                    if (item.storage.isNotBlank()) {
                        SpecRow("حافظه ذخیره‌سازی:", item.storage)
                    }
                    if (item.psu.isNotBlank()) {
                        SpecRow("پاور منبع تغذیه:", item.psu)
                    }
                    if (item.specs.isNotBlank() && item.cpu.isBlank()) {
                        Text(text = item.specs, style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            // Expandable Benchmarks and Pros/Cons
            if (item.fpsBenchmark.isNotBlank() || item.pros.isNotEmpty()) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { isExpanded = !isExpanded },
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isExpanded) "بستن جزئیات بنچمارک و مزایا" else "نمایش بنچمارک فریم‌ریت و مزایا",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = AgentIndigoPrimary
                    )
                    Icon(
                        imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                        contentDescription = null,
                        tint = AgentIndigoPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                if (isExpanded) {
                    Spacer(modifier = Modifier.height(6.dp))
                    if (item.fpsBenchmark.isNotBlank()) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = AgentCyanAccent.copy(alpha = 0.1f),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(imageVector = Icons.Default.Speed, contentDescription = null, tint = AgentCyanAccent, modifier = Modifier.size(16.dp))
                                Text(
                                    text = item.fpsBenchmark,
                                    style = MaterialTheme.typography.labelSmall.copy(lineHeight = 16.sp),
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }

                    if (item.pros.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(text = "مزایا و نقاط قوت:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = Color(0xFF10B981))
                        item.pros.forEach { pro ->
                            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("•", color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                                Text(text = pro, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }

                    if (item.cons.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "نکات قابل توجه:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = Color(0xFFF59E0B))
                        item.cons.forEach { con ->
                            Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text("•", color = Color(0xFFF59E0B), fontWeight = FontWeight.Bold)
                                Text(text = con, style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // Open in Browser Button
                Button(
                    onClick = onOpenUrl,
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AgentIndigoPrimary),
                    modifier = Modifier.weight(1.1f)
                ) {
                    Icon(imageVector = Icons.Default.OpenInBrowser, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("مشاهده در دیوار", style = MaterialTheme.typography.labelSmall)
                }

                // Ask About this Item Button
                OutlinedButton(
                    onClick = onAskAboutItem,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.ChatBubbleOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("استدلال درباره قطعات", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
    }
}

@Composable
fun SpecRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.widthIn(max = 110.dp)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurface,
            modifier = Modifier.weight(1f),
            fontSize = 11.sp
        )
    }
}

@Composable
fun ChatConversationView(
    chatMessages: List<AgentChatMessage>,
    taskProgressState: TaskProgressState,
    onOpenUrl: (String) -> Unit,
    onAskAboutItem: (String) -> Unit
) {
    if (chatMessages.isEmpty() && taskProgressState.actionHistory.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    imageVector = Icons.Default.Psychology,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.size(54.dp)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "به گفتگوی تحلیلی و تفکر عمیق خوش آمدید!",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
                Text(
                    text = "هرگونه سوال مقایسه‌ای، محاسباتی یا دستور جستجو را بپرسید",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        return
    }

    LazyColumn(
        verticalArrangement = Arrangement.spacedBy(10.dp),
        modifier = Modifier.fillMaxSize()
    ) {
        // Show active action timeline if running
        if (taskProgressState.actionHistory.isNotEmpty() && taskProgressState.status != TaskStatus.COMPLETED) {
            item {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "مراحل کاوش عمیق وب (${taskProgressState.actionHistory.size} گام انجام‌شده)",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = AgentIndigoPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        taskProgressState.actionHistory.forEach { act ->
                            ActionTimelineItem(act)
                            Spacer(modifier = Modifier.height(4.dp))
                        }
                    }
                }
            }
        }

        // Chat Message History
        items(chatMessages) { message ->
            ChatBubble(
                message = message,
                onOpenUrl = onOpenUrl,
                onAskAboutItem = onAskAboutItem
            )
        }
    }
}

@Composable
fun ChatBubble(
    message: AgentChatMessage,
    onOpenUrl: (String) -> Unit,
    onAskAboutItem: (String) -> Unit
) {
    val isUser = message.sender == MessageSender.USER

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        Row(
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.widthIn(max = 340.dp)
        ) {
            if (!isUser) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(AgentIndigoPrimary, AgentCyanAccent))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(imageVector = Icons.Default.Psychology, contentDescription = null, tint = Color.White, modifier = Modifier.size(15.dp))
                }
            }

            Surface(
                shape = RoundedCornerShape(
                    topStart = 16.dp,
                    topEnd = 16.dp,
                    bottomStart = if (isUser) 16.dp else 4.dp,
                    bottomEnd = if (isUser) 4.dp else 16.dp
                ),
                color = if (isUser) AgentIndigoPrimary else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = message.text,
                        style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 21.sp),
                        color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface
                    )

                    // If message contains structured report items, show preview
                    message.reportData?.items?.let { items ->
                        if (items.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "سیستم‌های منتخب رتبه‌بندی شده:",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                color = AgentIndigoPrimary
                            )
                            items.take(3).forEach { itm ->
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.5f))
                                        .clickable { onOpenUrl(itm.linkUrl) }
                                        .padding(6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(text = itm.title, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), maxLines = 1)
                                        Text(text = itm.price, style = MaterialTheme.typography.labelSmall, color = Color(0xFF10B981))
                                    }
                                    Icon(imageVector = Icons.Default.ChevronLeft, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun StatusBanner(state: TaskProgressState) {
    val (color, text, icon) = when (state.status) {
        TaskStatus.PLANNING -> Triple(AgentIndigoPrimary, "تفکر عمیق، استدلال و تصمیم‌گیری گام بعدی...", Icons.Default.Psychology)
        TaskStatus.EXECUTING -> Triple(AgentCyanAccent, "در حال کاوش چندمرحله‌ای صفحات وب...", Icons.Default.DirectionsRun)
        TaskStatus.WAITING_CONFIRMATION -> Triple(Color(0xFFF59E0B), "در انتظار تایید کاربر...", Icons.Default.Security)
        TaskStatus.PAUSED -> Triple(Color(0xFF6B7280), "عملیات متوقف شده است", Icons.Default.Pause)
        TaskStatus.COMPLETED -> Triple(Color(0xFF10B981), "کاوش، تفکر عمیق و استخراج نتایج پایان یافت!", Icons.Default.CheckCircle)
        TaskStatus.FAILED -> {
            val friendlyError = when {
                state.errorMessage?.contains("Navigate") == true -> "خطا در بارگذاری صفحه وب (لطفاً اتصال اینترنت خود را بررسی کنید)"
                state.errorMessage?.contains("timeout") == true -> "زمان پاسخ وب‌سایت به پایان رسید، لطفاً مجدداً امتحان نمایید"
                else -> state.errorMessage ?: "خطا در اجرای عملیات"
            }
            Triple(MaterialTheme.colorScheme.error, friendlyError, Icons.Default.Error)
        }
        TaskStatus.CANCELLED -> Triple(Color(0xFF6B7280), "عملیات لغو شد", Icons.Default.Cancel)
        else -> Triple(MaterialTheme.colorScheme.surfaceVariant, "", Icons.Default.Info)
    }

    Surface(
        color = color.copy(alpha = 0.15f),
        shape = RoundedCornerShape(14.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Icon(imageVector = icon, contentDescription = null, tint = color)
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = state.status.name,
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = color
                )
                Text(
                    text = text,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

@Composable
fun ConfirmationCard(
    request: ConfirmationRequest,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Confirmation Required",
                    tint = MaterialTheme.colorScheme.onErrorContainer
                )
                Text(
                    text = "نیازمند تایید کاربر",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(text = "عملیات: ${request.description}", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Text(text = "وب‌سایت هدف: ${request.targetWebsite}", style = MaterialTheme.typography.bodySmall)

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = request.onCancel) {
                    Text("انصراف", color = MaterialTheme.colorScheme.onErrorContainer)
                }
                Spacer(modifier = Modifier.width(8.dp))
                Button(
                    onClick = request.onConfirm,
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("تایید و ادامه", color = MaterialTheme.colorScheme.onError)
                }
            }
        }
    }
}

@Composable
fun ActionTimelineItem(action: AgentAction) {
    Surface(
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = Icons.Default.CheckCircle,
                contentDescription = null,
                tint = AgentCyanAccent,
                modifier = Modifier.size(16.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = action.describe(),
                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                )
                Text(
                    text = "هدف و استدلال: ${action.reason}",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}
