package com.example.browser

import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ElementBounds(
    val x: Int = 0,
    val y: Int = 0,
    val width: Int = 0,
    val height: Int = 0
)

@JsonClass(generateAdapter = true)
data class PageElement(
    val id: String,
    val type: String, // button, link, input, textarea, select, checkbox, radio, image, menu, other
    val text: String = "",
    val ariaLabel: String = "",
    val placeholder: String = "",
    val role: String = "",
    val enabled: Boolean = true,
    val visible: Boolean = true,
    val clickable: Boolean = true,
    val editable: Boolean = false,
    val href: String = "",
    val bounds: ElementBounds = ElementBounds()
)

@JsonClass(generateAdapter = true)
data class RawPageState(
    val url: String = "",
    val title: String = "",
    val elements: List<PageElement> = emptyList(),
    val bodyTextSummary: String = "",
    val isLoaded: Boolean = true
)

data class PageState(
    val url: String,
    val title: String,
    val elements: List<PageElement>,
    val bodyTextSummary: String,
    val isLoaded: Boolean,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun toCompactRepresentation(): String {
        val sb = StringBuilder()
        sb.append("PAGE TITLE: $title\n")
        sb.append("URL: $url\n")
        sb.append("INTERACTIVE ELEMENTS (${elements.size}):\n")
        elements.take(60).forEach { el ->
            val label = when {
                el.text.isNotBlank() -> el.text.trim()
                el.ariaLabel.isNotBlank() -> el.ariaLabel.trim()
                el.placeholder.isNotBlank() -> "Placeholder: ${el.placeholder.trim()}"
                else -> "Unlabeled ${el.type}"
            }
            val editableInfo = if (el.editable) " [Editable]" else ""
            sb.append("  - ID: ${el.id} | Type: ${el.type.uppercase()} | Label: \"$label\"$editableInfo\n")
        }
        if (bodyTextSummary.isNotBlank()) {
            sb.append("\nMAIN CONTENT TEXT:\n")
            sb.append(bodyTextSummary.take(1500))
        }
        return sb.toString()
    }
}
