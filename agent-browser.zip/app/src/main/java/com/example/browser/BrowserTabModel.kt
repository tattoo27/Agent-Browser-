package com.example.browser

import android.graphics.Bitmap
import android.webkit.WebView

data class BrowserTabModel(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String = "New Tab",
    val url: String = "about:blank",
    val favicon: Bitmap? = null,
    val isIncognito: Boolean = false,
    val isDesktopMode: Boolean = false,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false,
    val isLoading: Boolean = false,
    val progress: Int = 0,
    val webView: WebView? = null
)
