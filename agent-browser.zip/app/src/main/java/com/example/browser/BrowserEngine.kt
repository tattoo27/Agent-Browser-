package com.example.browser

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.net.http.SslError
import android.os.Environment
import android.webkit.*
import com.example.data.local.DownloadEntity
import com.example.data.repository.BrowserRepository
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.coroutines.resume

class BrowserEngine(
    private val context: Context,
    private val repository: BrowserRepository,
    private val scope: CoroutineScope
) {
    private val _tabs = MutableStateFlow<List<BrowserTabModel>>(emptyList())
    val tabs: StateFlow<List<BrowserTabModel>> = _tabs.asStateFlow()

    private val _activeTabId = MutableStateFlow<String>("")
    val activeTabId: StateFlow<String> = _activeTabId.asStateFlow()

    private val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
    private val rawPageStateAdapter = moshi.adapter(RawPageState::class.java)

    companion object {
        const val DESKTOP_USER_AGENT =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }

    init {
        // Create initial default tab metadata (WebView is created lazily on UI thread)
        createNewTab(url = "https://www.google.com")
    }

    fun getActiveTab(): BrowserTabModel? {
        val activeId = _activeTabId.value
        return _tabs.value.find { it.id == activeId } ?: _tabs.value.firstOrNull()
    }

    fun createNewTab(url: String = "https://www.google.com", isIncognito: Boolean = false): String {
        val tabId = java.util.UUID.randomUUID().toString()
        val formattedUrl = UrlValidator.formatOrValidateUrl(url)

        val newTab = BrowserTabModel(
            id = tabId,
            title = if (url == "about:blank") "New Tab" else "Loading...",
            url = formattedUrl,
            isIncognito = isIncognito,
            webView = null
        )

        _tabs.value = _tabs.value + newTab
        _activeTabId.value = tabId

        return tabId
    }

    fun ensureWebViewForTab(tabId: String, context: Context): WebView? {
        val tab = _tabs.value.find { it.id == tabId } ?: return null
        if (tab.webView != null) return tab.webView

        val webView = createConfiguredWebView(context, tab.isIncognito) ?: return null
        setupWebViewClients(tabId, webView)
        webView.loadUrl(tab.url)

        updateTab(tabId) { it.copy(webView = webView) }
        return webView
    }

    fun switchTab(tabId: String) {
        if (_tabs.value.any { it.id == tabId }) {
            _activeTabId.value = tabId
        }
    }

    fun closeTab(tabId: String) {
        val currentTabs = _tabs.value
        val tabToClose = currentTabs.find { it.id == tabId } ?: return

        tabToClose.webView?.apply {
            try {
                stopLoading()
                loadUrl("about:blank")
                onPause()
                clearHistory()
                clearCache(true)
                removeAllViews()
                destroy()
            } catch (t: Throwable) {
                // Ignore cleanup exceptions
            }
        }

        val remainingTabs = currentTabs.filter { it.id != tabId }
        _tabs.value = remainingTabs

        if (remainingTabs.isEmpty()) {
            createNewTab()
        } else if (_activeTabId.value == tabId) {
            _activeTabId.value = remainingTabs.last().id
        }
    }

    fun loadUrl(url: String) {
        val activeTab = getActiveTab() ?: return
        val formatted = UrlValidator.formatOrValidateUrl(url)
        updateTab(activeTab.id) { it.copy(url = formatted, title = "Loading...") }
        activeTab.webView?.post {
            try {
                activeTab.webView?.loadUrl(formatted)
            } catch (t: Throwable) {
                // Ignore
            }
        }
    }

    fun goBack() {
        val activeTab = getActiveTab() ?: return
        activeTab.webView?.post {
            if (activeTab.webView?.canGoBack() == true) {
                activeTab.webView?.goBack()
            }
        }
    }

    fun goForward() {
        val activeTab = getActiveTab() ?: return
        activeTab.webView?.post {
            if (activeTab.webView?.canGoForward() == true) {
                activeTab.webView?.goForward()
            }
        }
    }

    fun reload() {
        val activeTab = getActiveTab() ?: return
        activeTab.webView?.post {
            activeTab.webView?.reload()
        }
    }

    fun stopLoading() {
        val activeTab = getActiveTab() ?: return
        activeTab.webView?.post {
            activeTab.webView?.stopLoading()
        }
    }

    fun toggleDesktopMode() {
        val activeTab = getActiveTab() ?: return
        val newDesktop = !activeTab.isDesktopMode
        updateTab(activeTab.id) { it.copy(isDesktopMode = newDesktop) }

        activeTab.webView?.settings?.let { settings ->
            settings.userAgentString = if (newDesktop) DESKTOP_USER_AGENT else null
            settings.useWideViewPort = newDesktop
            settings.loadWithOverviewMode = newDesktop
        }
        activeTab.webView?.reload()
    }

    fun clearBrowsingData() {
        scope.launch {
            repository.clearHistory()
            _tabs.value.forEach { tab ->
                tab.webView?.clearHistory()
                tab.webView?.clearCache(true)
            }
            try {
                CookieManager.getInstance().removeAllCookies(null)
                WebStorage.getInstance().deleteAllData()
            } catch (t: Throwable) {
                // Ignore WebView storage errors
            }
        }
    }

    suspend fun extractPageState(): PageState = suspendCancellableCoroutine { continuation ->
        val activeTab = getActiveTab()
        val webView = activeTab?.webView

        if (webView == null) {
            continuation.resume(
                PageState(
                    url = activeTab?.url ?: "about:blank",
                    title = activeTab?.title ?: "No Page",
                    elements = emptyList(),
                    bodyTextSummary = "No active webview available.",
                    isLoaded = false
                )
            )
            return@suspendCancellableCoroutine
        }

        webView.post {
            try {
                webView.evaluateJavascript(PageUnderstandingBridge.EXTRACTION_JS) { jsonResult ->
                    if (jsonResult.isNullOrBlank() || jsonResult == "null") {
                        continuation.resume(
                            PageState(
                                url = webView.url ?: "about:blank",
                                title = webView.title ?: "Page",
                                elements = emptyList(),
                                bodyTextSummary = "Failed to evaluate JS extraction.",
                                isLoaded = true
                            )
                        )
                        return@evaluateJavascript
                    }

                    try {
                        val unescapedJson = if (jsonResult.startsWith("\"") && jsonResult.endsWith("\"")) {
                            val parsedString = moshi.adapter(String::class.java).fromJson(jsonResult)
                            parsedString ?: jsonResult
                        } else jsonResult

                        val raw = rawPageStateAdapter.fromJson(unescapedJson)
                        val pageState = PageState(
                            url = raw?.url ?: webView.url ?: "about:blank",
                            title = raw?.title ?: webView.title ?: "Page",
                            elements = raw?.elements ?: emptyList(),
                            bodyTextSummary = raw?.bodyTextSummary ?: "",
                            isLoaded = raw?.isLoaded ?: true
                        )
                        continuation.resume(pageState)
                    } catch (e: Exception) {
                        continuation.resume(
                            PageState(
                                url = webView.url ?: "about:blank",
                                title = webView.title ?: "Page",
                                elements = emptyList(),
                                bodyTextSummary = "Extraction parse error: ${e.message}",
                                isLoaded = true
                            )
                        )
                    }
                }
            } catch (t: Throwable) {
                continuation.resume(
                    PageState(
                        url = activeTab.url,
                        title = activeTab.title,
                        elements = emptyList(),
                        bodyTextSummary = "WebView error: ${t.message}",
                        isLoaded = false
                    )
                )
            }
        }
    }

    suspend fun executeJs(js: String): Boolean = suspendCancellableCoroutine { continuation ->
        val webView = getActiveTab()?.webView
        if (webView == null) {
            if (continuation.isActive) continuation.resume(true)
            return@suspendCancellableCoroutine
        }

        webView.post {
            try {
                webView.evaluateJavascript(js) { _ ->
                    if (continuation.isActive) {
                        continuation.resume(true)
                    }
                }
            } catch (t: Throwable) {
                if (continuation.isActive) continuation.resume(true)
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun createConfiguredWebView(ctx: Context, isIncognito: Boolean): WebView? {
        return try {
            WebView(ctx.applicationContext ?: ctx).apply {
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = !isIncognito
                    databaseEnabled = !isIncognito
                    allowFileAccess = false
                    allowContentAccess = false
                    setSupportZoom(true)
                    builtInZoomControls = true
                    displayZoomControls = false
                    mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
                }

                try {
                    val cookieManager = CookieManager.getInstance()
                    if (isIncognito) {
                        cookieManager.setAcceptCookie(false)
                    } else {
                        cookieManager.setAcceptCookie(true)
                        cookieManager.setAcceptThirdPartyCookies(this, true)
                    }
                } catch (t: Throwable) {
                    // CookieManager fallback
                }

                setDownloadListener { url, userAgent, contentDisposition, mimetype, contentLength ->
                    try {
                        val fileName = URLUtil.guessFileName(url, contentDisposition, mimetype)
                        val request = DownloadManager.Request(Uri.parse(url)).apply {
                            setMimeType(mimetype)
                            addRequestHeader("User-Agent", userAgent)
                            setTitle(fileName)
                            setDescription("Downloading file via Agent Browser...")
                            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                            setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
                        }

                        val downloadManager = ctx.getSystemService(Context.DOWNLOAD_SERVICE) as? DownloadManager
                        downloadManager?.enqueue(request)

                        scope.launch {
                            repository.addDownload(
                                DownloadEntity(
                                    id = java.util.UUID.randomUUID().toString(),
                                    fileName = fileName,
                                    url = url,
                                    mimeType = mimetype ?: "application/octet-stream",
                                    totalBytes = contentLength,
                                    status = "DOWNLOADING"
                                )
                            )
                        }
                    } catch (t: Throwable) {
                        // Fallback
                    }
                }
            }
        } catch (t: Throwable) {
            null
        }
    }

    private fun setupWebViewClients(tabId: String, webView: WebView) {
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                val scheme = uri.scheme?.lowercase() ?: ""

                if (scheme == "http" || scheme == "https" || scheme == "about") {
                    return false
                }

                try {
                    val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                } catch (t: Throwable) {
                    // Intent unresolved
                }
                return true
            }

            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.cancel()
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                url?.let {
                    updateTab(tabId) { t ->
                        t.copy(
                            url = it,
                            isLoading = true,
                            canGoBack = webView.canGoBack(),
                            canGoForward = webView.canGoForward()
                        )
                    }
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                val title = view?.title?.ifBlank { url } ?: url ?: "Web Page"
                url?.let {
                    updateTab(tabId) { t ->
                        t.copy(
                            title = title,
                            url = it,
                            isLoading = false,
                            progress = 100,
                            canGoBack = webView.canGoBack(),
                            canGoForward = webView.canGoForward()
                        )
                    }
                    if (!tIsIncognito(tabId)) {
                        scope.launch { repository.addHistory(title, it) }
                    }
                }
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                updateTab(tabId) { t ->
                    t.copy(
                        progress = newProgress,
                        isLoading = newProgress < 100
                    )
                }
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                title?.let { tTitle ->
                    updateTab(tabId) { t -> t.copy(title = tTitle) }
                }
            }

            override fun onReceivedIcon(view: WebView?, icon: Bitmap?) {
                icon?.let { tIcon ->
                    updateTab(tabId) { t -> t.copy(favicon = tIcon) }
                }
            }
        }
    }

    private fun tIsIncognito(tabId: String): Boolean {
        return _tabs.value.find { it.id == tabId }?.isIncognito ?: false
    }

    private fun updateTab(tabId: String, transform: (BrowserTabModel) -> BrowserTabModel) {
        _tabs.value = _tabs.value.map { tab ->
            if (tab.id == tabId) transform(tab) else tab
        }
    }
}
