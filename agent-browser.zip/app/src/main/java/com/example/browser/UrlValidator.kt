package com.example.browser

import android.webkit.URLUtil

object UrlValidator {

    private val BLOCKED_SCHEMES = setOf("file", "content", "javascript")

    fun formatOrValidateUrl(input: String, defaultSearchEngine: String = "Google"): String {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return "about:blank"

        val lower = trimmed.lowercase()
        if (BLOCKED_SCHEMES.any { lower.startsWith("$it:") || lower.startsWith("$it://") }) {
            return "about:blank"
        }

        // Direct check: If input starts with http:// or https://, it is a valid web URL
        if (lower.startsWith("http://") || lower.startsWith("https://")) {
            return trimmed
        }

        // Handle known search protocols or direct URLs via URLUtil
        if (URLUtil.isValidUrl(trimmed)) {
            val scheme = trimmed.substringBefore("://").lowercase()
            if (BLOCKED_SCHEMES.contains(scheme)) {
                return "about:blank"
            }
            return trimmed
        }

        // Check if input looks like a domain name without scheme (e.g. "example.com", "divar.ir", "wikipedia.org")
        if (isDomainName(trimmed)) {
            return "https://$trimmed"
        }

        // Build Search Engine Query
        val query = java.net.URLEncoder.encode(trimmed, "UTF-8")
        return when (defaultSearchEngine.lowercase()) {
            "duckduckgo" -> "https://duckduckgo.com/?q=$query"
            "bing" -> "https://www.bing.com/search?q=$query"
            "ecosia" -> "https://www.ecosia.org/search?q=$query"
            else -> "https://www.google.com/search?q=$query"
        }
    }

    private fun isDomainName(input: String): Boolean {
        if (input.contains(" ") || !input.contains(".")) return false
        val parts = input.split(".")
        if (parts.size < 2) return false
        val tld = parts.last().substringBefore("/").substringBefore("?")
        return tld.length >= 2 && tld.all { it.isLetter() }
    }

    fun isSafeScheme(url: String): Boolean {
        val lower = url.lowercase().trim()
        if (lower.startsWith("about:blank") || lower.startsWith("https://") || lower.startsWith("http://")) {
            return true
        }
        return false
    }
}
