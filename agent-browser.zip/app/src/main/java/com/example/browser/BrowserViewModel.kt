package com.example.browser

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppDatabase
import com.example.data.local.BookmarkEntity
import com.example.data.local.UserPreferenceEntity
import com.example.data.repository.BrowserRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class BrowserViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    val repository = BrowserRepository(db.browserDao())

    val engine = BrowserEngine(application, repository, viewModelScope)

    val tabs = engine.tabs
    val activeTabId = engine.activeTabId

    private val _urlInputText = MutableStateFlow("https://www.google.com")
    val urlInputText: StateFlow<String> = _urlInputText.asStateFlow()

    private val _isBookmarked = MutableStateFlow(false)
    val isBookmarked: StateFlow<Boolean> = _isBookmarked.asStateFlow()

    // Dialog & Overlay UI States
    private val _showTabSwitcher = MutableStateFlow(false)
    val showTabSwitcher: StateFlow<Boolean> = _showTabSwitcher.asStateFlow()

    private val _showBookmarksHistory = MutableStateFlow(false)
    val showBookmarksHistory: StateFlow<Boolean> = _showBookmarksHistory.asStateFlow()

    private val _showDownloads = MutableStateFlow(false)
    val showDownloads: StateFlow<Boolean> = _showDownloads.asStateFlow()

    private val _showSettings = MutableStateFlow(false)
    val showSettings: StateFlow<Boolean> = _showSettings.asStateFlow()

    private val _showAgentSheet = MutableStateFlow(false)
    val showAgentSheet: StateFlow<Boolean> = _showAgentSheet.asStateFlow()

    val userPreferences: StateFlow<UserPreferenceEntity> = repository.userPreferences
        .catch { emit(UserPreferenceEntity()) }
        .map { it ?: UserPreferenceEntity() }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), UserPreferenceEntity())

    val bookmarks = repository.allBookmarks
        .catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val history = repository.allHistory
        .catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val downloads = repository.allDownloads
        .catch { emit(emptyList()) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        // Sync URL bar text with active tab URL
        viewModelScope.launch {
            combine(engine.tabs, engine.activeTabId) { tabsList, activeId ->
                tabsList.find { it.id == activeId }
            }.collect { activeTab ->
                if (activeTab != null) {
                    _urlInputText.value = activeTab.url
                    _isBookmarked.value = try {
                        repository.isBookmarked(activeTab.url)
                    } catch (e: Exception) {
                        false
                    }
                }
            }
        }
    }

    fun onUrlInputChanged(newText: String) {
        _urlInputText.value = newText
    }

    fun navigateToUrl(url: String = _urlInputText.value) {
        engine.loadUrl(url)
    }

    fun toggleBookmark() {
        val activeTab = engine.getActiveTab() ?: return
        viewModelScope.launch {
            try {
                if (_isBookmarked.value) {
                    val current = bookmarks.value.find { it.url == activeTab.url }
                    if (current != null) {
                        repository.deleteBookmark(current.id)
                    }
                    _isBookmarked.value = false
                } else {
                    repository.addBookmark(
                        BookmarkEntity(
                            title = activeTab.title,
                            url = activeTab.url
                        )
                    )
                    _isBookmarked.value = true
                }
            } catch (e: Exception) {
                // Ignore DB write error
            }
        }
    }

    fun toggleTabSwitcher() {
        _showTabSwitcher.value = !_showTabSwitcher.value
    }

    fun toggleBookmarksHistory() {
        _showBookmarksHistory.value = !_showBookmarksHistory.value
    }

    fun toggleDownloads() {
        _showDownloads.value = !_showDownloads.value
    }

    fun toggleSettings() {
        _showSettings.value = !_showSettings.value
    }

    fun toggleAgentSheet(show: Boolean? = null) {
        _showAgentSheet.value = show ?: !_showAgentSheet.value
    }

    fun updatePreferences(prefs: UserPreferenceEntity) {
        viewModelScope.launch {
            try {
                repository.savePreferences(prefs)
            } catch (e: Exception) {
                // Ignore DB write error
            }
        }
    }

    fun clearHistory() {
        viewModelScope.launch {
            try {
                repository.clearHistory()
            } catch (e: Exception) {
                // Ignore DB write error
            }
        }
    }
}
