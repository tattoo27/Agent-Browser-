package com.example.browser

object PageUnderstandingBridge {

    /**
     * JS Script injected into the WebView to extract structured PageState.
     */
    val EXTRACTION_JS = """
        (function() {
            try {
                let elementCounter = 0;
                const elements = [];
                const selector = 'a, button, input, textarea, select, [role="button"], [role="link"], [role="checkbox"], [role="menuitem"], [onclick]';
                const nodeMap = new Map();

                document.querySelectorAll(selector).forEach((el) => {
                    const rect = el.getBoundingClientRect();
                    const style = window.getComputedStyle(el);
                    
                    const isVisible = rect.width > 0 && rect.height > 0 && 
                                      style.visibility !== 'hidden' && 
                                      style.display !== 'none' && 
                                      rect.bottom >= 0 && rect.top <= window.innerHeight;

                    if (!isVisible) return;

                    let agentId = el.getAttribute('data-agent-id');
                    if (!agentId) {
                        agentId = 'el_' + (++elementCounter);
                        el.setAttribute('data-agent-id', agentId);
                    }

                    let type = el.tagName.toLowerCase();
                    if (type === 'a') type = 'link';
                    else if (type === 'input') {
                        const inputType = (el.getAttribute('type') || 'text').toLowerCase();
                        if (inputType === 'checkbox') type = 'checkbox';
                        else if (inputType === 'radio') type = 'radio';
                        else if (inputType === 'button' || inputType === 'submit') type = 'button';
                        else type = 'input';
                    } else if (el.getAttribute('role') === 'button') type = 'button';

                    const text = (el.innerText || el.value || el.textContent || '').trim().substring(0, 100);
                    const ariaLabel = (el.getAttribute('aria-label') || el.getAttribute('title') || '').trim().substring(0, 100);
                    const placeholder = (el.getAttribute('placeholder') || '').trim().substring(0, 100);
                    const role = el.getAttribute('role') || '';
                    const href = (el.tagName.toLowerCase() === 'a' ? (el.getAttribute('href') || el.href || '') : '').trim();
                    const enabled = !el.disabled;
                    const clickable = true;
                    const editable = type === 'input' || type === 'textarea' || el.isContentEditable;

                    elements.push({
                        id: agentId,
                        type: type,
                        text: text,
                        ariaLabel: ariaLabel,
                        placeholder: placeholder,
                        role: role,
                        enabled: enabled,
                        visible: true,
                        clickable: clickable,
                        editable: editable,
                        href: href,
                        bounds: {
                            x: Math.round(rect.left),
                            y: Math.round(rect.top),
                            width: Math.round(rect.width),
                            height: Math.round(rect.height)
                        }
                    });
                });

                // Extract main body text summary
                let bodyText = document.body ? document.body.innerText : '';
                if (bodyText.length > 2000) {
                    bodyText = bodyText.substring(0, 2000);
                }

                return JSON.stringify({
                    url: window.location.href,
                    title: document.title,
                    elements: elements,
                    bodyTextSummary: bodyText,
                    isLoaded: document.readyState === 'complete'
                });
            } catch (e) {
                return JSON.stringify({
                    url: window.location.href,
                    title: document.title,
                    elements: [],
                    bodyTextSummary: "Error extracting page: " + e.message,
                    isLoaded: true
                });
            }
        })();
    """.trimIndent()

    fun buildClickJs(id: String): String {
        val sanitizedId = id.replace("\"", "\\\"")
        return """
            (function() {
                const el = document.querySelector('[data-agent-id="$sanitizedId"]');
                if (el) {
                    el.scrollIntoView({behavior: 'smooth', block: 'center'});
                    el.focus();
                    el.click();
                    return true;
                }
                return false;
            })();
        """.trimIndent()
    }

    fun buildTypeJs(id: String, text: String): String {
        val sanitizedId = id.replace("\"", "\\\"")
        val sanitizedText = text.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n")
        return """
            (function() {
                const el = document.querySelector('[data-agent-id="$sanitizedId"]');
                if (el) {
                    el.scrollIntoView({behavior: 'smooth', block: 'center'});
                    el.focus();
                    el.value = "$sanitizedText";
                    el.dispatchEvent(new Event('input', { bubbles: true }));
                    el.dispatchEvent(new Event('change', { bubbles: true }));
                    return true;
                }
                return false;
            })();
        """.trimIndent()
    }

    fun buildClearJs(id: String): String {
        val sanitizedId = id.replace("\"", "\\\"")
        return """
            (function() {
                const el = document.querySelector('[data-agent-id="$sanitizedId"]');
                if (el) {
                    el.focus();
                    el.value = '';
                    el.dispatchEvent(new Event('input', { bubbles: true }));
                    el.dispatchEvent(new Event('change', { bubbles: true }));
                    return true;
                }
                return false;
            })();
        """.trimIndent()
    }

    fun buildScrollJs(direction: String): String {
        val amount = if (direction.lowercase() == "up") -600 else 600
        return """
            (function() {
                window.scrollBy({ top: $amount, behavior: 'smooth' });
                return true;
            })();
        """.trimIndent()
    }

    fun buildSelectJs(id: String, optionValue: String): String {
        val sanitizedId = id.replace("\"", "\\\"")
        val sanitizedOption = optionValue.replace("\"", "\\\"")
        return """
            (function() {
                const el = document.querySelector('[data-agent-id="$sanitizedId"]');
                if (el && el.tagName.toLowerCase() === 'select') {
                    for (let i = 0; i < el.options.length; i++) {
                        if (el.options[i].value === "$sanitizedOption" || el.options[i].text.includes("$sanitizedOption")) {
                            el.selectedIndex = i;
                            el.dispatchEvent(new Event('change', { bubbles: true }));
                            return true;
                        }
                    }
                }
                return false;
            })();
        """.trimIndent()
    }
}
