package com.example.security

import com.example.agent.AgentAction
import com.example.browser.PageState

data class ConfirmationRequest(
    val id: String = java.util.UUID.randomUUID().toString(),
    val actionName: String,
    val description: String,
    val targetWebsite: String,
    val submittedData: String?,
    val potentialConsequence: String,
    val onConfirm: () -> Unit,
    val onCancel: () -> Unit
)

object HumanInTheLoopManager {

    private val DANGEROUS_KEYWORDS = listOf(
        "pay", "buy", "purchase", "checkout", "card", "cvv", "social security",
        "ssn", "password", "pass", "delete", "remove account", "transfer", "send money",
        "confirm order", "place order", "submit form", "subscribe", "login"
    )

    fun requiresConfirmation(
        action: AgentAction,
        pageState: PageState,
        alwaysConfirmSensitive: Boolean = true
    ): Boolean {
        if (!alwaysConfirmSensitive) return false

        val reasonLower = action.reason.lowercase()
        val descLower = action.describe().lowercase()

        if (DANGEROUS_KEYWORDS.any { reasonLower.contains(it) || descLower.contains(it) }) {
            return true
        }

        when (action) {
            is AgentAction.Type -> {
                val valueLower = action.value.lowercase()
                val targetElement = pageState.elements.find { it.id == action.targetId }
                val targetText = ((targetElement?.text ?: "") + " " + (targetElement?.ariaLabel ?: "") + " " + (targetElement?.placeholder ?: "")).lowercase()

                if (DANGEROUS_KEYWORDS.any { valueLower.contains(it) || targetText.contains(it) }) {
                    return true
                }
            }
            is AgentAction.Click -> {
                val targetElement = pageState.elements.find { it.id == action.targetId }
                val label = ((targetElement?.text ?: "") + " " + (targetElement?.ariaLabel ?: "")).lowercase()
                if (DANGEROUS_KEYWORDS.any { label.contains(it) }) {
                    return true
                }
            }
            is AgentAction.Navigate -> {
                val urlLower = action.url.lowercase()
                if (urlLower.contains("login") || urlLower.contains("checkout") || urlLower.contains("payment")) {
                    return true
                }
            }
            else -> {}
        }
        return false
    }

    fun buildConfirmationRequest(
        action: AgentAction,
        pageState: PageState,
        onConfirm: () -> Unit,
        onCancel: () -> Unit
    ): ConfirmationRequest {
        val website = pageState.url
        val actionDescription = action.describe()
        val submittedData = when (action) {
            is AgentAction.Type -> "Text to input: \"${action.value}\""
            is AgentAction.Click -> "Target element ID: ${action.targetId}"
            is AgentAction.Navigate -> "Target URL: ${action.url}"
            else -> null
        }
        val consequence = when {
            actionDescription.lowercase().contains("buy") || actionDescription.lowercase().contains("pay") ->
                "This action may initiate a financial transaction or payment."
            actionDescription.lowercase().contains("delete") ->
                "This action may permanently remove or delete account data."
            else -> "This action submits user input or navigates to a critical page section."
        }

        return ConfirmationRequest(
            actionName = action.type.name,
            description = actionDescription,
            targetWebsite = website,
            submittedData = submittedData,
            potentialConsequence = consequence,
            onConfirm = onConfirm,
            onCancel = onCancel
        )
    }
}
