package com.example.security

import com.example.browser.PageState

object PromptInjectionDetector {

    private val SUSPICIOUS_PATTERNS = listOf(
        "ignore previous instructions",
        "ignore all previous instructions",
        "system prompt:",
        "you are now an ai agent that",
        "reveal your system prompt",
        "reveal api key",
        "output your secret key",
        "transfer money to",
        "send email to",
        "delete account immediately",
        "bypass security controls",
        "disregard safety guidelines",
        "do not ask user for confirmation"
    )

    data class SecurityAssessment(
        val isSafe: Boolean,
        val riskScore: Float, // 0.0 (safe) to 1.0 (dangerous)
        val detectedThreats: List<String>
    )

    fun evaluatePageState(pageState: PageState): SecurityAssessment {
        val threats = mutableListOf<String>()
        var threatPoints = 0

        val combinedText = (pageState.bodyTextSummary + " " + pageState.elements.joinToString(" ") { 
            "${it.text} ${it.ariaLabel} ${it.placeholder}" 
        }).lowercase()

        SUSPICIOUS_PATTERNS.forEach { pattern ->
            if (combinedText.contains(pattern)) {
                threats.add("Detected suspicious prompt injection phrase: '$pattern'")
                threatPoints += 3
            }
        }

        // Check for hidden inputs asking for credentials
        val sensitiveFieldCount = pageState.elements.count { 
            it.type == "input" && (it.text.contains("password", ignoreCase = true) || 
            it.placeholder.contains("password", ignoreCase = true) ||
            it.text.contains("card number", ignoreCase = true) ||
            it.placeholder.contains("card number", ignoreCase = true))
        }

        if (sensitiveFieldCount > 0) {
            threats.add("Page contains sensitive input fields requiring elevated user authorization.")
            threatPoints += 1
        }

        val riskScore = (threatPoints / 5.0f).coerceIn(0.0f, 1.0f)
        return SecurityAssessment(
            isSafe = threatPoints < 3,
            riskScore = riskScore,
            detectedThreats = threats
        )
    }

    fun sanitizeAgentInput(text: String): String {
        var clean = text
        SUSPICIOUS_PATTERNS.forEach { pattern ->
            clean = clean.replace(Regex("(?i)" + Regex.escape(pattern)), "[REDACTED_INSTRUCTION]")
        }
        return clean
    }
}
