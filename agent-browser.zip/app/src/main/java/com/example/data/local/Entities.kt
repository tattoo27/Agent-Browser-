package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tabs")
data class TabEntity(
    @PrimaryKey val id: String,
    val title: String,
    val url: String,
    val faviconUrl: String? = null,
    val isIncognito: Boolean = false,
    val isDesktopMode: Boolean = false,
    val lastAccessedAt: Long = System.currentTimeMillis(),
    val position: Int = 0
)

@Entity(tableName = "bookmarks")
data class BookmarkEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val url: String,
    val category: String = "General",
    val faviconUrl: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val url: String,
    val timestamp: Long = System.currentTimeMillis(),
    val visitCount: Int = 1
)

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val id: String,
    val fileName: String,
    val url: String,
    val mimeType: String,
    val totalBytes: Long = 0,
    val downloadedBytes: Long = 0,
    val status: String = "PENDING", // PENDING, DOWNLOADING, COMPLETED, FAILED
    val filePath: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "agent_tasks")
data class AgentTaskEntity(
    @PrimaryKey val id: String,
    val userPrompt: String,
    val status: String, // PLANNING, RUNNING, WAITING_CONFIRMATION, COMPLETED, FAILED, CANCELLED
    val currentStep: Int = 0,
    val maxSteps: Int = 50,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null,
    val resultSummary: String? = null
)

@Entity(tableName = "agent_steps")
data class AgentStepEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskId: String,
    val stepIndex: Int,
    val actionType: String,
    val targetElementId: String? = null,
    val actionValue: String? = null,
    val reasoning: String,
    val pageUrl: String,
    val status: String, // EXECUTING, SUCCESS, FAILED, REJECTED
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "user_preferences")
data class UserPreferenceEntity(
    @PrimaryKey val id: Int = 1,
    val confirmDangerousActions: Boolean = true,
    val preferredSearchEngine: String = "Google", // Google, DuckDuckGo, Bing, Ecosia
    val defaultDesktopMode: Boolean = false,
    val maxStepsPerTask: Int = 50,
    val blockUnsafeSites: Boolean = true,
    val enableVoiceInput: Boolean = true,
    val selectedAiProvider: String = "FREE", // FREE, GEMINI, OPENAI, CLAUDE, CUSTOM_OPENAI
    val selectedAiModel: String = "gemini-2.5-flash",
    val geminiApiKey: String = "",
    val openAiApiKey: String = "",
    val claudeApiKey: String = "",
    val customApiBaseUrl: String = "",
    val customApiKey: String = "",
    val apiGatewayUrl: String = ""
)
