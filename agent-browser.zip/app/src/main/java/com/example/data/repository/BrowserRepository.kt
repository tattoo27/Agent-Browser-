package com.example.data.repository

import com.example.data.local.*
import kotlinx.coroutines.flow.Flow

class BrowserRepository(private val dao: BrowserDao) {

    // Tabs
    val allTabs: Flow<List<TabEntity>> = dao.getAllTabs()
    suspend fun saveTab(tab: TabEntity) = dao.insertTab(tab)
    suspend fun saveTabs(tabs: List<TabEntity>) = dao.insertTabs(tabs)
    suspend fun deleteTab(id: String) = dao.deleteTab(id)
    suspend fun deleteAllTabs() = dao.deleteAllTabs()

    // Bookmarks
    val allBookmarks: Flow<List<BookmarkEntity>> = dao.getAllBookmarks()
    suspend fun addBookmark(bookmark: BookmarkEntity) = dao.insertBookmark(bookmark)
    suspend fun deleteBookmark(id: Long) = dao.deleteBookmark(id)
    suspend fun isBookmarked(url: String): Boolean = dao.isBookmarked(url)

    // History
    val allHistory: Flow<List<HistoryEntity>> = dao.getAllHistory()
    suspend fun addHistory(title: String, url: String) {
        if (url.isBlank() || url.startsWith("about:") || url.startsWith("data:")) return
        dao.insertHistory(HistoryEntity(title = title.ifBlank { url }, url = url))
    }
    suspend fun searchHistory(query: String) = dao.searchHistory(query)
    suspend fun deleteHistory(id: Long) = dao.deleteHistoryItem(id)
    suspend fun clearHistory() = dao.clearHistory()

    // Downloads
    val allDownloads: Flow<List<DownloadEntity>> = dao.getAllDownloads()
    suspend fun addDownload(download: DownloadEntity) = dao.insertDownload(download)
    suspend fun updateDownloadProgress(id: String, downloadedBytes: Long, totalBytes: Long, status: String) =
        dao.updateDownloadProgress(id, downloadedBytes, totalBytes, status)
    suspend fun deleteDownload(id: String) = dao.deleteDownload(id)

    // Agent Tasks & Steps
    val allAgentTasks: Flow<List<AgentTaskEntity>> = dao.getAllAgentTasks()
    suspend fun getTaskById(taskId: String) = dao.getTaskById(taskId)
    suspend fun saveTask(task: AgentTaskEntity) = dao.insertTask(task)
    fun getStepsForTask(taskId: String): Flow<List<AgentStepEntity>> = dao.getStepsForTask(taskId)
    suspend fun saveStep(step: AgentStepEntity) = dao.insertStep(step)

    // Preferences
    val userPreferences: Flow<UserPreferenceEntity?> = dao.getUserPreferences()
    suspend fun savePreferences(prefs: UserPreferenceEntity) = dao.saveUserPreferences(prefs)
}
