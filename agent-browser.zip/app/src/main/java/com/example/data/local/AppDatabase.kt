package com.example.data.local

import android.content.Context
import android.util.Log
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        TabEntity::class,
        BookmarkEntity::class,
        HistoryEntity::class,
        DownloadEntity::class,
        AgentTaskEntity::class,
        AgentStepEntity::class,
        UserPreferenceEntity::class
    ],
    version = 5,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun browserDao(): BrowserDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                try {
                    val instance = buildDatabase(context)
                    INSTANCE = instance
                    instance
                } catch (e: Exception) {
                    Log.e("AppDatabase", "Failed to build Room database, purging old database file.", e)
                    try {
                        context.applicationContext.deleteDatabase("agent_browser_db")
                    } catch (t: Throwable) {
                        Log.e("AppDatabase", "Error deleting corrupt database", t)
                    }
                    val freshInstance = buildDatabase(context)
                    INSTANCE = freshInstance
                    freshInstance
                }
            }
        }

        private fun buildDatabase(context: Context): AppDatabase {
            return Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "agent_browser_db"
            )
            .fallbackToDestructiveMigration(true)
            .build()
        }
    }
}
